Magick::ImageList.new('uid.pdf') do
  self.quality = 80
  self.density = '300'  
  self.interlace = Magick::NoInterlace
end.each_with_index do |img, i|  
  img.write("test-#{i}.jpg")
end