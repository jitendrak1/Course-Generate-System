class FacultyController < Devise::RegistrationsController

	

	private

	def sign_up_params
		params.require(:faculty).permit(:name, :email, :password, :password_confirmation, :department, :designation, :academic_degrees, :curriculum_vitae)
	end

	def account_update_params
		params.require(:faculty).permit(:name, :email, :password, :password_confirmation, :current_password, :department, :designation, :academic_degrees, :curriculum_vitae)
	end
end
