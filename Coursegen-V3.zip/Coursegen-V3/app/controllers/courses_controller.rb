require 'RMagick'
class CoursesController < ApplicationController

  before_action :set_course, only: [:show, :edit, :update, :destroy]
  before_action :authenticate_faculty!
  # GET /courses
  # GET /courses.json
  def index
    @courses = current_faculty.courses.all.order("created_at DESC")
  end

  # GET /courses/1
  # GET /courses/1.json
  def show    
    @faculty= current_faculty
    @img_path = "file path"
    respond_to do |format|
      format.html              
      format.pdf do          
       render :pdf => 'Coursefile',
       :template => 'courses/show.pdf.erb',
       :layout => 'pdf.html.erb',
       header: { right: '[page] of [topage]' },
       :show_as_html => params[:debug].present?



     end      
   end
 end

  # GET /courses/new
  def new
    @course = current_faculty.courses.build
  end

  # GET /courses/1/edit
  def edit
  end

  # POST /courses
  # POST /courses.json
  def create
    @course = current_faculty.courses.build(course_params)
    @defaults = ['Mid-term I Evaluation', 'Mid-term II Evaluation', 'End Semester Exam']


    @course.schedules.new(title: 'Mid-term I Evaluation' , start_date: 30.days.from_now, end_date: 40.days.from_now )
    @course.schedules.new(title: 'Mid-term II Evaluation' , start_date: 60.days.from_now, end_date: 70.days.from_now )
    @course.schedules.new(title: 'End Semester Exam' , start_date: 100.days.from_now, end_date: 110.days.from_now )
    
    respond_to do |format|
      if @course.save
        format.html { redirect_to @course, notice: 'Course was successfully created.' }
        format.json { render :show, status: :created, location: @course }
      else
        format.html { render :new }
        format.json { render json: @course.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /courses/1
  # PATCH/PUT /courses/1.json
  def update
    respond_to do |format|
      if @course.update(course_params)
        format.html { redirect_to @course, notice: 'Course was successfully updated.' }
        format.json { render :show, status: :ok, location: @course }
      else
        format.html { render :edit }
        format.json { render json: @course.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /courses/1
  # DELETE /courses/1.json
  def destroy
    @course.destroy
    respond_to do |format|
      format.html { redirect_to courses_url, notice: 'Course was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def create_pdf_image

    require 'RMagick'
    
    @document = current_faculty.courses.find(params[:id])
    pdf = Prawn::Document.new
    temp = "#{@document.user.name.downcase.parameterize.underscore}-#{@document.id}"
    @document.post_pdf(pdf)
    pdf.render_file("#{temp}.pdf")
    image = Magick::ImageList.new("#{temp}.pdf")

    image.each_with_index do |page_img, i|
      image.write("#{temp}.png") { self.quality = 100 }
      send_file "#{temp}.png"
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_course      
      @course = current_faculty.courses.find(params[:id])      
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def course_params
      params.require(:course).permit(:title, :description, :session, :confined_marks_sheet, :prerequisites,:syllabus, :academic_calendar, :attendance_sheet, :book_list, :final_result, :students_list, :semester_time_table, schedules_attributes: [:id, :title, :start_date,:end_date,:completed_at,:attachment, :_destroy])
    end
  end
