class FolderCleanupJob < ActiveJob::Base
  queue_as :default

  def perform(*args)
    # Do something later
    File.delete(Rails.root + '/file.jpg')
  end
end
