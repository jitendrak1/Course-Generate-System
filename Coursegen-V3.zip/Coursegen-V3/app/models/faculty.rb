class Faculty < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable
  has_many :courses
  has_attached_file :curriculum_vitae
  validates_attachment_content_type :curriculum_vitae, content_type: [/\Aimage\/.*\Z/ , "application/pdf"]
  
  def user_params
      params.require(:faculty).permit(:curriculum_vitae)
   end
end
