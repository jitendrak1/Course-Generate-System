class Course < ActiveRecord::Base
	belongs_to :faculty
	has_many :schedules
	accepts_nested_attributes_for :schedules, :allow_destroy => true,
  :reject_if => proc { |a| a['title'].blank? }
  validates :title, :description, :session, presence: true
  has_attached_file :syllabus
  validates_attachment_content_type :syllabus, content_type: [/\Aimage\/.*\Z/ , "application/pdf" ]

   has_attached_file :academic_calendar
  validates_attachment_content_type :academic_calendar, content_type: [/\Aimage\/.*\Z/ , "application/pdf" ]

   has_attached_file :students_list
  validates_attachment_content_type :students_list, content_type: [/\Aimage\/.*\Z/ , "application/pdf" ]

   has_attached_file :final_result
  validates_attachment_content_type :final_result, content_type: [/\Aimage\/.*\Z/ , "application/pdf" ]

   has_attached_file :attendance_sheet
  validates_attachment_content_type :attendance_sheet, content_type: [/\Aimage\/.*\Z/ , "application/pdf" ]

   has_attached_file :book_list
  validates_attachment_content_type :book_list, content_type: [/\Aimage\/.*\Z/ , "application/pdf" ]

    has_attached_file :semester_time_table
  validates_attachment_content_type :semester_time_table, content_type: [/\Aimage\/.*\Z/ , "application/pdf" ]

    has_attached_file :confined_marks_sheet
  validates_attachment_content_type :confined_marks_sheet, content_type: [/\Aimage\/.*\Z/ , "application/pdf" ]

   def pdf2img(url)
    url="#{url.split("?")[0]}"
    path = Rails.root.join("public/#{url}")
    pdf= File.open(path,'rb').read


    Magick::Image::from_blob(pdf) do
      self.quality = 80
      self.density = '150'           
      self.page = 'a4'   
      self.interlace = Magick::NoInterlace
    end
  end
  def makeimg(url)
    path = Rails.root.join("public/#{url}")
    pdf= File.open(path,'rb').read


    Magick::Image::from_blob(pdf) do
      self.quality = 80
      self.density = '150'         
      self.page = 'a4'         
      self.interlace = Magick::NoInterlace
    end
  end
end
