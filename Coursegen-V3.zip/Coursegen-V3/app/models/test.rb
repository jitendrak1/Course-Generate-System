class Test < ActiveRecord::Base
	has_attached_file :attachment, styles: { :medium => "400x400#" }
   	validates_attachment_content_type :attachment, content_type: [/\Aimage\/.*\Z/ , "application/pdf","application/vnd.ms-excel",     
             "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
             "application/msword", 
             "application/vnd.openxmlformats-officedocument.wordprocessingml.document", 
             "text/plain"]

    def convert_pdf_to_images(pdf_url)
    	
    	# require 'RMagick'
    	# pdf= Magick::ImageList.new(pdf_url)
    end
end
