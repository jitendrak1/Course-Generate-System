Rails.application.routes.draw do
  resources :tests    
  devise_for :faculties, controllers: {registrations: "faculty"}
  resources :courses

  root 'courses#index'
  
end
