class AddAttachmentConfinedMarksSheetToCourses < ActiveRecord::Migration
  def self.up
    change_table :courses do |t|
      t.attachment :confined_marks_sheet
    end
  end

  def self.down
    remove_attachment :courses, :confined_marks_sheet
  end
end
