class AddFacultyToCourses < ActiveRecord::Migration
  def change
    add_reference :courses, :faculty, index: true, foreign_key: true
  end
end
