class AddFacultyProfileAttributes < ActiveRecord::Migration
  def change
  	change_table(:faculties) do |t| 
      t.string   :department
      t.string :name
      t.string :designation
      t.string   :academic_degrees # Only if using reconfirmable
  	end
  end
end
