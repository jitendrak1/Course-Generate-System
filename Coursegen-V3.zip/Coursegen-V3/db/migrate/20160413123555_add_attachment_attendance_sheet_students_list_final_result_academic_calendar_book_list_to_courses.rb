class AddAttachmentAttendanceSheetStudentsListFinalResultAcademicCalendarBookListToCourses < ActiveRecord::Migration
  def self.up
    change_table :courses do |t|
      t.attachment :attendance_sheet
      t.attachment :students_list
      t.attachment :final_result
      t.attachment :academic_calendar
      t.attachment :book_list
    end
  end

  def self.down
    remove_attachment :courses, :attendance_sheet
    remove_attachment :courses, :students_list
    remove_attachment :courses, :final_result
    remove_attachment :courses, :academic_calendar
    remove_attachment :courses, :book_list
  end
end
