class AddAttachmentSemesterTimeTableToCourses < ActiveRecord::Migration
  def self.up
    change_table :courses do |t|
      t.attachment :semester_time_table
    end
  end

  def self.down
    remove_attachment :courses, :semester_time_table
  end
end
