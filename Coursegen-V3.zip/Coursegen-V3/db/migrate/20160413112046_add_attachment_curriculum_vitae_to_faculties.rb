class AddAttachmentCurriculumVitaeToFaculties < ActiveRecord::Migration
  def self.up
    change_table :faculties do |t|
      t.attachment :curriculum_vitae
    end
  end

  def self.down
    remove_attachment :faculties, :curriculum_vitae
  end
end
