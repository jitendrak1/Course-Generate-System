class AddAttachmentAttachmentToSchedules < ActiveRecord::Migration
  def self.up
    change_table :schedules do |t|
      t.attachment :attachment
    end
  end

  def self.down
    remove_attachment :schedules, :attachment
  end
end
