class AddAttachmentAttachmentToTests < ActiveRecord::Migration
  def self.up
    change_table :tests do |t|
      t.attachment :attachment
    end
  end

  def self.down
    remove_attachment :tests, :attachment
  end
end
