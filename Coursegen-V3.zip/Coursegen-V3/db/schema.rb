# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160413141703) do

  create_table "courses", force: :cascade do |t|
    t.string   "title"
    t.text     "description"
    t.string   "session"
    t.text     "prerequisites"
    t.datetime "created_at",                        null: false
    t.datetime "updated_at",                        null: false
    t.string   "syllabus_file_name"
    t.string   "syllabus_content_type"
    t.integer  "syllabus_file_size"
    t.datetime "syllabus_updated_at"
    t.integer  "faculty_id"
    t.string   "attendance_sheet_file_name"
    t.string   "attendance_sheet_content_type"
    t.integer  "attendance_sheet_file_size"
    t.datetime "attendance_sheet_updated_at"
    t.string   "students_list_file_name"
    t.string   "students_list_content_type"
    t.integer  "students_list_file_size"
    t.datetime "students_list_updated_at"
    t.string   "final_result_file_name"
    t.string   "final_result_content_type"
    t.integer  "final_result_file_size"
    t.datetime "final_result_updated_at"
    t.string   "academic_calendar_file_name"
    t.string   "academic_calendar_content_type"
    t.integer  "academic_calendar_file_size"
    t.datetime "academic_calendar_updated_at"
    t.string   "book_list_file_name"
    t.string   "book_list_content_type"
    t.integer  "book_list_file_size"
    t.datetime "book_list_updated_at"
    t.string   "semester_time_table_file_name"
    t.string   "semester_time_table_content_type"
    t.integer  "semester_time_table_file_size"
    t.datetime "semester_time_table_updated_at"
    t.string   "confined_marks_sheet_file_name"
    t.string   "confined_marks_sheet_content_type"
    t.integer  "confined_marks_sheet_file_size"
    t.datetime "confined_marks_sheet_updated_at"
  end

  add_index "courses", ["faculty_id"], name: "index_courses_on_faculty_id"

  create_table "faculties", force: :cascade do |t|
    t.string   "email",                         default: "", null: false
    t.string   "encrypted_password",            default: "", null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",                 default: 0,  null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.datetime "created_at",                                 null: false
    t.datetime "updated_at",                                 null: false
    t.string   "confirmation_token"
    t.datetime "confirmed_at"
    t.datetime "confirmation_sent_at"
    t.string   "unconfirmed_email"
    t.string   "department"
    t.string   "name"
    t.string   "designation"
    t.string   "academic_degrees"
    t.string   "curriculum_vitae_file_name"
    t.string   "curriculum_vitae_content_type"
    t.integer  "curriculum_vitae_file_size"
    t.datetime "curriculum_vitae_updated_at"
  end

  add_index "faculties", ["email"], name: "index_faculties_on_email", unique: true
  add_index "faculties", ["reset_password_token"], name: "index_faculties_on_reset_password_token", unique: true

  create_table "schedules", force: :cascade do |t|
    t.string   "title"
    t.date     "start_date"
    t.date     "end_date"
    t.date     "completed_at"
    t.integer  "course_id"
    t.datetime "created_at",              null: false
    t.datetime "updated_at",              null: false
    t.string   "attachment_file_name"
    t.string   "attachment_content_type"
    t.integer  "attachment_file_size"
    t.datetime "attachment_updated_at"
  end

  add_index "schedules", ["course_id"], name: "index_schedules_on_course_id"

  create_table "tests", force: :cascade do |t|
    t.datetime "created_at",              null: false
    t.datetime "updated_at",              null: false
    t.string   "attachment_file_name"
    t.string   "attachment_content_type"
    t.integer  "attachment_file_size"
    t.datetime "attachment_updated_at"
  end

end
